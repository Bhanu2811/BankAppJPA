package com.fis.bankapplication.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;

import com.fis.bankapplication.model.Account;


public interface AccountDao extends JpaRepository<Account , Long>  {

	
//    public abstract String addAccdet(Account acc);
//    
//    public abstract String updateAccdet(Account acc);
//    
//    public abstract String delAccdet(long accId);
//    
//    public abstract Account getAccount(long accId);
//    
//    public abstract List<Account> getAllAccounts();
//    
	
	@Query("update Account a set a.accBalance = accBalance + ?2 where a.accNum= ?1")
    @Modifying
    public  void deposit (long accNum , double accBal);
	@Query("update Account a set a.accBalance = accBalance - ?2 where a.accNum= ?1 ")
	@Modifying
	 public  void withdraw(long accNum, double accBal);
	 
//    public abstract String deposit (long accNum , double accBal) throws AccountNotFound; // Exception Added
//    
//    public abstract String withdraw(long accNum, double accBal) throws LessBalanceException ,AccountNotFound; // Exception Added
//    
//    public abstract String fundTransfer(long accNum1, long accnum2, double accBal,String type2) throws LessBalanceException, AccountNotFound;  // Exception Added
}

