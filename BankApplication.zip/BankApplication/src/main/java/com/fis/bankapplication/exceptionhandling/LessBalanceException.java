package com.fis.bankapplication.exceptionhandling;

public class LessBalanceException extends Exception {
	
	public LessBalanceException(String message) {
		super(message);
	}

}
