package com.fis.bankapplication.controller;

import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.fis.bankapplication.model.Customer;
import com.fis.bankapplication.service.CustomerService;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;



//{
//	"customerId" : 101,
//	"customerName" : "Bhanu",
//	"customerDob" : 2000-11-28,
//	"customerPno" : 7093893837,
//	"customerMail" : " bhanu@mail.com",
//	"customerPerAdd": "Ap",
//	"customerCurrAdd" : "Pune",
//	"password" : "bhanu@123";
//	"occupation" : "IT"
//}
@RestController
@RequestMapping("/customer")
public class CustomerController {
	@Autowired
	CustomerService cusserv;
	
	@PostMapping("/addCustomer")// http://localhost:1111/customer/addCustomer
	public  String addCusdet (@RequestBody @Validated Customer cus) {
		return cusserv.addCusdet(cus);
	}
	
	@PutMapping("/updateCustomer")// http://localhost:1111/customer/updateCustomer
	public String updateCusdet(@RequestBody Customer cus) {
		return cusserv.updateCusdet(cus);
	}
	
	@DeleteMapping("/deleteCustomer/{cid}")// http://localhost:1111/customer/deleteCustomer/101
	public String delCusdet(@PathVariable("cid") int cusId) {
		return cusserv.delCusdet(cusId);
	}
	@GetMapping("/getCustomer/{cid}") // http://localhost:1111/customer/getcustomer/111
	public Customer getCustomer(@PathVariable("cid") int cusID) {
		return cusserv.getCustomer(cusID);
	}
	
	@GetMapping("/getAllCustomers") // http://localhost:1111/customer/getAllCustomers
	public List<Customer> getAllCustomer() {
		return cusserv.getAllCustomer();
	}
}
